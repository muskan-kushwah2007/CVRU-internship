// Custom Logger Middleware

const logger = (req, res, next) => {
console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
next();
};

module.exports = logger;
